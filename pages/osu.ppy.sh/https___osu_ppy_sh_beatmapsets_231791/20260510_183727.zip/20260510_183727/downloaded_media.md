## Downloaded Media Files

![apple-touch-icon.png](./media/apple-touch-icon.png)
![favicon-16x16.png](./media/favicon-16x16.png)
![favicon-32x32.png](./media/favicon-32x32.png)
![safari-pinned-tab.svg](./media/safari-pinned-tab.svg)
